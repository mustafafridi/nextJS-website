import Link from "next/link";

export default function ProductCard({ product }: any) {
  return (
    <Link
      href={`/products/${product.slug}`}
      className="border rounded-2xl overflow-hidden hover:shadow-lg transition bg-white"
    >
      <img
        src={product.image}
        alt={product.name}
        className="w-full h-60 object-cover"
      />

      <div className="p-5">
        <h3 className="font-semibold text-lg">{product.name}</h3>

        <p className="text-sm text-gray-500 mt-2 line-clamp-2">
          {product.description}
        </p>

        <p className="mt-4 font-bold">€{product.price}</p>
      </div>
    </Link>
  );
}