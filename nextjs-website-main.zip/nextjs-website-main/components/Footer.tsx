export default function Footer() {
    return (
      <footer className="w-full border-t mt-20">
        <div className="max-w-6xl mx-auto px-6 py-10 text-center text-sm text-gray-500">
          
          <p className="font-medium text-black">Ivya Store</p>
  
          <p className="mt-2">
            © {new Date().getFullYear()} All rights reserved.
          </p>
  
          <p className="mt-1">
            Built with Next.js & Tailwind CSS
          </p>
        </div>
      </footer>
    );
  }