import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="w-full border-b bg-white">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        
        {/* Logo */}
        <Link href="/" className="text-xl font-bold">
          Ivya Store
        </Link>

        {/* Links */}
        <div className="flex gap-6 text-sm font-medium">
          <Link href="/" className="hover:underline">
            Home
          </Link>

          <Link href="/products" className="hover:underline">
            Products
          </Link>

          <Link href="/about" className="hover:underline">
            About
          </Link>

          <Link href="/contact" className="hover:underline">
            Contact
          </Link>
        </div>
      </div>
    </nav>
  );
}