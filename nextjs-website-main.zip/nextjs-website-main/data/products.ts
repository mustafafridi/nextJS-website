export type Product = {
    name: string;
    slug: string;
    price: number;
    image: string;
    description: string;
  };
  
  export const products: Product[] = [
    {
      name: "Himalayan Pink Salt",
      slug: "himalayan-pink-salt",
      price: 10,
      image: "/salt1.jpg",
      description: "Mineral-rich natural salt from the Himalayas.",
    },
    {
      name: "Sea Salt",
      slug: "sea-salt",
      price: 8,
      image: "/salt2.jpg",
      description: "Pure sea salt crystals for everyday use.",
    },
    {
      name: "Black Salt",
      slug: "black-salt",
      price: 12,
      image: "/salt3.jpg",
      description: "Distinctive flavor with natural minerals.",
    },
  ];