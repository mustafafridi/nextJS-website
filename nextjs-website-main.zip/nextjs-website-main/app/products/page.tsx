import { products } from "@/data/products";
import ProductCard from "@/components/ProductCard";

export default function ProductsPage() {
  return (
    <main className="min-h-screen bg-white">

      {/* HEADER */}
      <section className="border-b bg-gradient-to-r from-gray-50 to-white">
        <div className="max-w-6xl mx-auto px-6 py-20 text-center">
          <h1 className="text-5xl font-bold tracking-tight">
            Our Products
          </h1>

          <p className="mt-6 text-gray-600 max-w-2xl mx-auto text-lg">
            Discover our collection of premium mineral-rich salts,
            carefully sourced and crafted for everyday use.
          </p>
        </div>
      </section>

      {/* PRODUCTS GRID */}
      <section className="max-w-6xl mx-auto px-6 py-16">
        
        {/* Optional toolbar (future-ready) */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-10 gap-4">
          <p className="text-gray-600 text-sm">
            {products.length} products
          </p>

          <select className="border rounded-lg px-4 py-2 text-sm w-full sm:w-auto">
            <option>Sort by: Featured</option>
            <option>Price: Low to High</option>
            <option>Price: High to Low</option>
            <option>Name: A → Z</option>
          </select>
        </div>

        {/* GRID */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <ProductCard key={product.slug} product={product} />
          ))}
        </div>
      </section>

      {/* BOTTOM CTA */}
      <section className="bg-black text-white py-20 text-center px-6 mt-20">
        <h2 className="text-3xl font-semibold">
          Pure. Natural. Essential.
        </h2>

        <p className="mt-4 text-gray-300 max-w-xl mx-auto">
          Every grain of IVYA salt is sourced with care to bring you
          unmatched purity and taste.
        </p>

        <button className="mt-8 px-8 py-3 bg-white text-black rounded-full hover:opacity-80 transition">
          Learn More
        </button>
      </section>

    </main>
  );
}