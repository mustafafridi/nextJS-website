import { products } from "@/data/products";

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const product = products.find((p) => p.slug === slug);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold">Product not found</h1>
          <p className="text-gray-500 mt-2">
            The product you’re looking for doesn’t exist.
          </p>
        </div>
      </div>
    );
  }

  return (
    <main className="max-w-6xl mx-auto px-6 py-16 grid md:grid-cols-2 gap-12">

      {/* IMAGE */}
      <div className="w-full">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-[500px] object-cover rounded-2xl shadow"
        />
      </div>

      {/* DETAILS */}
      <div className="flex flex-col justify-center">
        <h1 className="text-4xl font-bold">{product.name}</h1>

        <p className="mt-4 text-gray-600 leading-relaxed">
          {product.description}
        </p>

        <p className="mt-6 text-3xl font-semibold">
          €{product.price}
        </p>

        <button className="mt-8 px-8 py-3 bg-black text-white rounded-full hover:opacity-80 transition">
          Add to Cart
        </button>
      </div>

    </main>
  );
}