export default function ContactPage() {
    return (
      <main className="min-h-screen bg-white">
  
        {/* HEADER */}
        <section className="border-b bg-gradient-to-r from-gray-50 to-white">
          <div className="max-w-4xl mx-auto px-6 py-20 text-center">
            <h1 className="text-5xl font-bold tracking-tight">
              Contact Us
            </h1>
  
            <p className="mt-6 text-gray-600 text-lg">
              We’d love to hear from you. Send us a message and we’ll get back to you soon.
            </p>
          </div>
        </section>
  
        {/* CONTACT SECTION */}
        <section className="max-w-5xl mx-auto px-6 py-16 grid md:grid-cols-2 gap-12">
  
          {/* FORM */}
          <form className="space-y-5">
  
            <div>
              <label className="text-sm font-medium">Name</label>
              <input
                type="text"
                placeholder="Your name"
                className="w-full mt-2 border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-black"
              />
            </div>
  
            <div>
              <label className="text-sm font-medium">Email</label>
              <input
                type="email"
                placeholder="you@example.com"
                className="w-full mt-2 border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-black"
              />
            </div>
  
            <div>
              <label className="text-sm font-medium">Message</label>
              <textarea
                rows={5}
                placeholder="Write your message..."
                className="w-full mt-2 border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-black"
              />
            </div>
  
            <button
              type="button"
              className="w-full bg-black text-white py-3 rounded-full hover:opacity-80 transition"
            >
              Send Message
            </button>
          </form>
  
          {/* INFO PANEL */}
          <div className="bg-gray-50 rounded-2xl p-8 flex flex-col justify-center">
            <h2 className="text-2xl font-semibold">Get in touch</h2>
  
            <p className="mt-4 text-gray-600">
              Whether you have a question about our products, pricing, or anything else,
              our team is ready to answer all your questions.
            </p>
  
            <div className="mt-8 space-y-3 text-sm">
              <p><strong>Email:</strong> support@ivya.com</p>
              <p><strong>Phone:</strong> +49 123 456 789</p>
              <p><strong>Hours:</strong> Mon–Fri, 9am – 6pm</p>
            </div>
  
            <div className="mt-8 text-xs text-gray-500">
              We usually respond within 24 hours.
            </div>
          </div>
  
        </section>
  
      </main>
    );
  }