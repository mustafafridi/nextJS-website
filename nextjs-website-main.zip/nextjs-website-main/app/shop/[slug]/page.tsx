export default function ProductPage() {
    return (
      <div className="p-10 max-w-4xl mx-auto">
        <img src="/salt1.jpg" className="rounded-xl w-full h-96 object-cover" />
  
        <h1 className="text-4xl font-bold mt-6">
          Himalayan Pink Salt
        </h1>
  
        <p className="mt-4 text-gray-600">
          Natural, mineral-rich salt perfect for cooking and wellness.
        </p>
  
        <p className="mt-4 text-2xl font-bold">€10</p>
  
        <button className="mt-6 px-8 py-3 bg-black text-white rounded-full">
          Buy Now
        </button>
      </div>
    );
  }