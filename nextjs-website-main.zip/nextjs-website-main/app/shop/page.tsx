import Navbar from "@/components/Navbar";
import ProductCard from "@/components/ProductCard";

const products = [
  { name: "Pink Salt", price: 10, image: "/salt1.jpg" },
  { name: "Sea Salt", price: 8, image: "/salt2.jpg" },
  { name: "Black Salt", price: 12, image: "/salt3.jpg" },
];

export default function Shop() {
  return (
    <main>
      <Navbar />

      <div className="px-10 py-20">
        <h1 className="text-4xl font-bold mb-10 text-center">Shop</h1>

        <div className="grid md:grid-cols-3 gap-8">
          {products.map((p, i) => (
            <ProductCard key={i} product={p} />
          ))}
        </div>
      </div>
    </main>
  );
}