import Navbar from "@/components/Navbar";

export default function About() {
  return (
    <main>
      <Navbar />

      <section className="px-6 py-20 max-w-4xl mx-auto text-center">
        <h1 className="text-4xl font-bold">About IVYA</h1>

        <p className="mt-6 text-gray-600 leading-relaxed">
          IVYA is dedicated to delivering premium, natural salts sourced
          from the finest regions around the world. Our mission is to
          bring purity, quality, and authenticity to every kitchen.
        </p>

        <p className="mt-6 text-gray-600 leading-relaxed">
          We believe that something as simple as salt should be
          exceptional. That’s why every product we offer is carefully
          selected and crafted to meet the highest standards.
        </p>
      </section>
      
      <section className="py-24 bg-gray-50 text-center">
        <h2 className="text-3xl font-semibold">Our Story</h2>

        <p className="mt-6 max-w-2xl mx-auto text-gray-600">
            IVYA was created with a simple idea: elevate everyday essentials.
        </p>
      </section>

      
    </main>
  );
}

