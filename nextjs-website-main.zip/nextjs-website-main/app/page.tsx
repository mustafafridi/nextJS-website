import ProductCard from "@/components/ProductCard";
import { products } from "@/data/products";

export default function Home() {
  return (
    <main className="flex flex-col">

      {/* HERO */}
      <section className="text-center py-28 px-6 bg-gradient-to-r from-pink-100 via-white to-white">
        <h1 className="text-6xl font-bold tracking-tight">
          IVYA Salt
        </h1>

        <p className="mt-6 text-lg text-gray-600 max-w-2xl mx-auto">
          Premium mineral-rich salt sourced directly from nature.
          Crafted for taste, purity, and everyday wellness.
        </p>

        <button className="mt-10 px-8 py-3 bg-black text-white rounded-full hover:opacity-80 transition">
          Shop Now
        </button>
      </section>

      {/* PRODUCTS */}
      <section className="py-24 px-6 max-w-6xl mx-auto w-full">
        <h2 className="text-3xl font-semibold text-center mb-12">
          Our Products
        </h2>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-8">
          {products.map((p) => (
            <ProductCard key={p.slug} product={p} />
          ))}
        </div>
      </section>

      {/* STORY */}
      <section className="bg-gray-50 py-24 px-6 text-center">
        <h2 className="text-3xl font-semibold">Why IVYA?</h2>

        <p className="mt-6 max-w-3xl mx-auto text-gray-600 leading-relaxed">
          At IVYA, we bring you the purest salts sourced from the finest
          natural regions. Our products are mineral-rich, unrefined, and
          carefully selected to enhance your everyday cooking experience.
        </p>
      </section>

    </main>
  );
}